a = int(input())
b = int(input())
c = int(input())
d = int(input())
e = int(input())

answers = []

for x in range(0, 1000+1):
    if x != e and ((a*x**3 + b*x**2 + c*x + d) / (x - e)) == 0:
        answers.append(x)
print(len(answers))