n = int(input())
while n >= 1:
    n /= 2
    if n == 1: break
if n == 1: print('YES')
else: print('NO')