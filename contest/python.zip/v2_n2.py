a = int(input())
b = int(input())
c = int(input())
d = int(input())

answers = []

for x in range(0, 1000+1):
    if (a*x**3 + b*x**2 + c*x + d) == 0:
        answers.append(x)
for i in range(len(answers), 0, -1):
    print(i)