n = int(input())
answer = []
for i in range(n):
    for j in range(i):
        answer.append(i)
print(answer)