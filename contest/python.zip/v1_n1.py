numbers = [int(input())]
while sum(numbers) != 0: numbers.append(int(input()))
for i in range(len(numbers)): numbers[i] *= numbers[i]
print(sum(numbers)) 